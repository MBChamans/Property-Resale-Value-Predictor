from flask import Flask,request, url_for, redirect, render_template
import pickle
import numpy as np

app = Flask(__name__)

modelLR=pickle.load(open('modelLR.pkl','rb'))
modelKNN=pickle.load(open('modelKNN.pkl','rb'))
modelDT=pickle.load(open('modelDT.pkl','rb'))

@app.route('/')
def hello_world():
    return render_template("index.html")

@app.route('/')
def hello_world():
    return render_template("index.html")

@app.route('/predict',methods=['POST','GET'])
def predict():
    a=[]
    locality=request.form.get("local")
    carparea=int(request.form.get("area"))
    bed=int(request.form.get("noofbedr"))
    parking=int(request.form.get("park"))
    gym=int(request.form.get("gym"))
    pool=int(request.form.get("swimpool"))
    lift=int(request.form.get("lift"))
    resale=int(request.form.get("resale"))
    for i in range (len(dict)):
        if(dict[i]['Location']==locality):
            locid=dict[i]['Location ID']
            appa=dict[i]['Avg_Price_Area']
    final=[np.array([carparea,appa,locid,bed,resale,gym,lift,parking,pool])]
    prediction1=modelLR.predict(final)
    prediction2=modelKNN.predict(final)
    prediction3=modelDT.predict(final)
    output = prediction1*0.1 + prediction2*0.3 + prediction3*0.6
    predict="{:,}".format(int(output[0][0]))
    return render_template('index.html',pred=predict)
 
if __name__ == '__main__':
    app.run()
  
